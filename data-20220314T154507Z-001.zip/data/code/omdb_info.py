import re

import pandas as pd
import requests
import pathlib

omdb_api = 'http://www.omdbapi.com/?apikey=7682433c&plot=full'
df = pd.DataFrame()
tgt_path = pathlib.Path.cwd().joinpath('./kontrol_altyazi')
index = 0
for file in tgt_path.iterdir():
    imdb_id = file.name.split('.')[0]
    print(imdb_id)
    response = requests.get(omdb_api, params={'i': imdb_id}).json()
    for key in response:
        if key == 'Awards':
            awards = re.findall(r"(\d*)\s(Oscar|win|nomination)", response['Awards'])
            for award in awards:
                df.at[index, award[1].capitalize()] = award[0]
        elif key == 'Ratings':
            for val in response['Ratings']:
                df.at[index, val['Source']] = val['Value']
        else:
            df.at[index, key] = response[key]
    index += 1
    df.to_csv('./results/yaslilik_kontrol.csv', encoding='utf-8', index=False)
