import pathlib
from collections import defaultdict
from pysentimiento import create_analyzer
import spacy
import pandas as pd
import srt

sentiment_analyzer = create_analyzer(task="sentiment", lang="en")
emotion_analyzer = create_analyzer(task="emotion", lang="en")
hate_speech_analyzer = create_analyzer(task="hate_speech", lang="en")
nlp = spacy.load("en_core_web_sm")
df = pd.DataFrame()

tgt_path = pathlib.Path.cwd().joinpath('./tests')
index = 0
for file in tgt_path.iterdir():
    with open(file, 'r', encoding="utf8") as f:
        subs = list(srt.parse(f.read()))
        imdb_id = file.name.split('.')[0]
        for sub in subs:
            doc = nlp(sub.content)
            sentiment_analyzer_output = sentiment_analyzer.predict(sub.content)
            emotion_analyzer_output = emotion_analyzer.predict(sub.content)
            hate_speech_analyzer_output = hate_speech_analyzer.predict(sub.content)
            df.at[index, 'ImdbId'] = imdb_id
            df.at[index, 'text'] = sub.content
            df.at[index, 'sentiment'] = sentiment_analyzer_output.output
            df.at[index, 'NEU'] = sentiment_analyzer_output.probas['NEU']
            df.at[index, 'POS'] = sentiment_analyzer_output.probas['POS']
            df.at[index, 'NEG'] = sentiment_analyzer_output.probas['NEG']
            df.at[index, 'emotion'] = emotion_analyzer_output.output
            df.at[index, 'joy'] = emotion_analyzer_output.probas['joy']
            df.at[index, 'others'] = emotion_analyzer_output.probas['others']
            df.at[index, 'surprise'] = emotion_analyzer_output.probas['surprise']
            df.at[index, 'disgust'] = emotion_analyzer_output.probas['disgust']
            df.at[index, 'sadness'] = emotion_analyzer_output.probas['sadness']
            df.at[index, 'fear'] = emotion_analyzer_output.probas['fear']
            df.at[index, 'anger'] = emotion_analyzer_output.probas['anger']
            df.at[index, 'hate_speech'] = hate_speech_analyzer_output.output
            df.at[index, 'hateful'] = emotion_analyzer_output.probas['hateful']
            df.at[index, 'targeted'] = emotion_analyzer_output.probas['targeted']
            df.at[index, 'aggressive'] = emotion_analyzer_output.probas['aggressive']
            token_dict = defaultdict(list)
            for token in doc:
                token_dict[token.pos_].append(token.lemma_)
            df.at[index, token.pos_] = ' '.join(token_dict[token.pos_])
            index += 1

df.to_csv('result.csv', encoding='utf-8', index=False)
